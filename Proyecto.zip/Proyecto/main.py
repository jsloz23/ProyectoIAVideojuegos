import pygame
import sys
from os import path
from settings import *
from sprites import *
from tilemap import *

class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption(TITLE)
        self.clock = pygame.time.Clock()
        pygame.key.set_repeat(500, 100)
        self.loadData()

    def loadData(self):
        gameFolder = path.dirname(__file__)
        imageFolder = path.join(gameFolder,'img')
        self.map = Map(path.join(gameFolder, 'map.txt'))
        self.playerImage = pygame.image.load(path.join(imageFolder, PLAYERIMAGE)).convert_alpha()
        self.mobImage = pygame.image.load(path.join(imageFolder, MOBIMAGE)).convert_alpha()
        self.bulletImage = pygame.image.load(path.join(imageFolder, BULLETIMAGE)).convert_alpha()
        self.wallImage = pygame.image.load(path.join(imageFolder, WALLIMAGE)).convert_alpha()
        self.wallImage = pygame.transform.scale(self.wallImage, (TILESIZE, TILESIZE))


    def new(self):
        # initialize all variables and do all the setup for a new game
        self.allSprites = pygame.sprite.Group()
        self.walls = pygame.sprite.Group()
        self.mobs = pygame.sprite.Group()
        self.bullets = pygame.sprite.Group()
        for row, tiles in enumerate(self.map.data):
        	for col, tile in enumerate(tiles):
        		if tile == '1':
        			Wall(self,col,row)
        		if tile == 'M':
        			Mob(self, col, row)
        		if tile == 'P':
        			self.player = Player(self, col, row)
        self.camera = Camera(self.map.width, self.map.height)


    def run(self):
        # game loop - set self.playing = False to end the game
        self.playing = True
        while self.playing:
            self.dt = self.clock.tick(FPS) / 1000
            self.events()
            self.update()
            self.draw()

    def quit(self):
        pygame.quit()
        sys.exit()

    def update(self):
        # update portion of the game loop
        self.allSprites.update()
        self.camera.update(self.player)
        #mobs hit player
        
        # bullets hit mobs
        hits = pygame.sprite.groupcollide(self.mobs, self.bullets, False, True)
        for hit in hits:
        	hit.health -= BULLETDAMAGE
        	hit.vel = vec(0, 0)

    def drawGrid(self):
        for x in range(0, WIDTH, TILESIZE):
            pygame.draw.line(self.screen, LIGHTGREY, (x, 0), (x, HEIGHT))
        for y in range(0, HEIGHT, TILESIZE):
            pygame.draw.line(self.screen, LIGHTGREY, (0, y), (WIDTH, y))

    def draw(self):
    	pygame.display.set_caption("{:.2f}".format(self.clock.get_fps()))
    	self.screen.fill(BGCOLOR)
    	#self.drawGrid()
    	for sprite in self.allSprites:
    		if isinstance(sprite, Mob):
    			sprite.drawHealth()
    		self.screen.blit(sprite.image, self.camera.apply(sprite))
    	pygame.display.flip()

    def events(self):
        # catch all events here
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.quit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.quit()

    def showStartScreen(self):
        pass

    def showGameOverScreen(self):
        pass

# create the game object
g = Game()
g.showStartScreen()
while True:
    g.new()
    g.run()
    g.showGameOverScreen()
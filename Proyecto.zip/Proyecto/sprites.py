import pygame
from settings import *
from tilemap import collideHitRect
from random import uniform
vec = pygame.math.Vector2

def collideWithWalls(sprite, group, dir):
		if dir == 'x':
			hits = pygame.sprite.spritecollide(sprite, group, False, collideHitRect)
			if hits:
				if sprite.vel.x > 0:
					sprite.pos.x = hits[0].rect.left - sprite.hitRect.width/2
				if sprite.vel.x < 0:
					sprite.pos.x = hits[0].rect.right + sprite.hitRect.width/2
				sprite.vel.x = 0
				sprite.hitRect.centerx = sprite.pos.x

		if dir == 'y':
			hits = pygame.sprite.spritecollide(sprite, group, False, collideHitRect)
			if hits:
				if sprite.vel.y > 0:
					sprite.pos.y = hits[0].rect.top - sprite.hitRect.height/2
				if sprite.vel.y < 0:
					sprite.pos.y = hits[0].rect.bottom + sprite.hitRect.height/2
				sprite.vel.y = 0
				sprite.hitRect.centery = sprite.pos.y

#SPRITE CLASSES
class Player(pygame.sprite.Sprite):
	def __init__(self, game, x, y):
		self.groups = game.allSprites
		pygame.sprite.Sprite.__init__(self, self.groups)
		self.game = game
		self.image = game.playerImage
		self.rect = self.image.get_rect()
		self.hitRect = PLAYERHITRECT
		self.hitRect.center = self.rect.center
		self.vel = vec(0,0)
		self.pos = vec(x,y) * TILESIZE
		self.rot = 0
		self.lastShot = 0
		self.health = PLAYERHEALTH

	def getKeys(self):
		self.rotSpeed = 0
		self.vel = vec(0,0)
		keys = pygame.key.get_pressed()
		if keys[pygame.K_LEFT] or keys[pygame.K_a]:
			self.rotSpeed = PLAYERROTSPEED
		if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
			self.rotSpeed = -PLAYERROTSPEED
		if keys[pygame.K_UP] or keys[pygame.K_w]:
			self.vel = vec(PLAYERSPEED,0).rotate(-self.rot)
		if keys[pygame.K_DOWN] or keys[pygame.K_s]:
			self.vel = vec(-PLAYERSPEED/2,0).rotate(-self.rot)
		if keys[pygame.K_SPACE]:
			now = pygame.time.get_ticks()
			if now - self.lastShot > BULLETRATE:
				self.lastShot = now
				dir = vec(1,0).rotate(-self.rot)
				pos = self.pos + BARRELOFFSET.rotate(-self.rot)
				Bullet(self.game, pos, dir)
				self.vel = vec(-KICKBACK, 0).rotate(-self.rot)

	def update(self):
		self.getKeys()
		self.rot = (self.rot + self.rotSpeed * self.game.dt) % 360
		self.image = pygame.transform.rotate(self.game.playerImage, self.rot)
		self.rect = self.image.get_rect()
		self.rect.center = self.pos
		self.pos += self.vel*self.game.dt
		self.hitRect.centerx = self.pos.x
		collideWithWalls(self, self.game.walls, 'x')
		self.hitRect.centery = self.pos.y
		collideWithWalls(self, self.game.walls, 'y')
		self.rect.center = self.hitRect.center


class Mob(pygame.sprite.Sprite):
	def __init__(self, game, x, y):
		self.groups = game.allSprites, game.mobs
		pygame.sprite.Sprite.__init__(self, self.groups)
		self.game = game
		self.image = game.mobImage
		self.rect = self.image.get_rect()
		self.hitRect = MOBHITRECT.copy()
		self.hitRect.center = self.hitRect.center
		self.pos = vec(x, y) * TILESIZE
		self.vel = vec(0, 0)
		self.acc = vec(0, 0)
		self.rect.center = self.pos
		self.rot = 0
		self.health = MOBHEALTH

	def update(self):
		self.rot = (self.game.player.pos - self.pos).angle_to(vec(1,0))
		self.image = pygame.transform.rotate(self.game.mobImage, self.rot)
		self.rect = self.image.get_rect()
		self.rect.center = self.pos
		self.acc = vec(MOBSPEED, 0).rotate(-self.rot)
		self.acc += self.vel * -1
		self.vel +=	self.acc * self.game.dt
		self.pos += self.vel * self.game.dt + 0.5 * self.acc * self.game.dt ** 2
		self.hitRect.centerx = self.pos.x
		collideWithWalls(self, self.game.walls, 'x')
		self.hitRect.centery = self.pos.y
		collideWithWalls(self, self.game.walls, 'y')
		self.rect.center = self.hitRect.center
		if self.health <= 0:
			self.kill()

	def drawHealth(self):
		if self.health > 60:
			col = GREEN
		elif self.health > 30:
			col = YELLOW
		else:
			col = RED

		width = int(self.rect.width * self.health/MOBHEALTH)
		self.healthBar = pygame.Rect(0, 0, width, 7)
		if self.health < MOBHEALTH:
			pygame.draw.rect(self.image, col, self.healthBar)

class Bullet(pygame.sprite.Sprite):
	def __init__(self, game, pos, dir):
		self.groups = game.allSprites, game.bullets
		pygame.sprite.Sprite.__init__(self, self.groups)
		self.game = game
		self.image = game.bulletImage
		self.rect = self.image.get_rect()
		self.pos = vec(pos)
		self.rect.center = pos
		spread = uniform(-GUNSPREAD, GUNSPREAD)
		self.vel = dir.rotate(spread) * BULLETSPEED
		self.spawnTime = pygame.time.get_ticks()

	def update(self):
		self.pos += self.vel * self.game.dt
		self.rect.center = self.pos
		if pygame.sprite.spritecollideany(self, self.game.walls):
			self.kill()
		if pygame.time.get_ticks() - self.spawnTime > BULLETLIFETIME:
			self.kill()


class Wall(pygame.sprite.Sprite):
	def __init__(self, game, x, y):
		self.groups = game.allSprites, game.walls
		pygame.sprite.Sprite.__init__(self, self.groups)
		self.game = game
		self.image = game.wallImage
		self.rect = self.image.get_rect()
		self.x = x
		self.y = y
		self.rect.x = x * TILESIZE
		self.rect.y = y * TILESIZE